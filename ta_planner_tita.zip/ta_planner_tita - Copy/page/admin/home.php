<div class="jumbotron" style="margin-top:50px">
      <div class="row">
      <div class="col-md-4" style="margin:20px;">
      <img src="../../img/moon.jpg" width="300"> 
    </div>
      <div class="col-md-6" style="margin-top: 50px;">
        <h2><b>Selamat datang di Halaman Admin Moon Planner</b></h2>
        <p>Disini anda bisa mengatur dan memanagemen dari data <b>Kategori</b>, <b>Barang</b> dan <b>Data Customer.</b></p>
      </div>
    </div>
    </div>